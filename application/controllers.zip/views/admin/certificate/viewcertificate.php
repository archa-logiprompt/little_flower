<body>
    <!-- https://www.smashingmagazine.com/2015/01/designing-for-print-with-css/ -->
    <img src="img/tc5.png" class="tcmybg" width="100%" height="100%" />
    <div class="tc-container">
        <table style="width: 80%; margin:0 auto">
            <tr>
                <td colspan="3" valign="top" style="text-align:center; font-size:36px; padding-bottom: 100px;">Transfer Certificate</td>
            </tr>
            <tr>
                <td valign="top" style="font-size: 18px; width: 33%; font-weight: bold;text-align:left;">Test</td>
                <td valign="top" style="font-size: 18px; width: 33%; font-weight: bold;text-align:center;">Test</td>
                <td valign="top" style="font-size: 18px; width: 33%; font-weight: bold;text-align:right;">Test</td>
            </tr>
            <tr>
                <td colspan="3" valign="top"><p style="font-size: 14px;text-align:center;  padding-top: 30px;">By the present, I certified that rarer serer, of 2018-02-21 years old, who lives in Jabalpur Madhya Pradesh, being her/his guardian rahyl , is a active student for this institution since 12-03-2017 By the present, I certified that rarer serer, of 2018-02-21 years old, who lives in Jabalpur Madhya Pradesh, being her/his guardian rahyl , is a active student for this institution since 12-03-2017</p>
                    <p style="font-size: 14px; text-align:center; padding-bottom: 80px;">By the present, I certified that rarer serer, of 2018-02-21 years old, who lives in Jabalpur Madhya Pradesh, being her/his guardian rahyl , is a active student for this institution since 12-03-2017 By the present, I certified that rarer serer, of 2018-02-21 years old, who lives in Jabalpur Madhya Pradesh, being her/his guardian rahyl , is a active student for this institution since 12-03-2017</p></td>
            </tr>
            <tr>
                <td valign="top" style="font-size:20px;width: 33%; text-align:left;">Principal</td>
                <td valign="top" style="font-size:20px;width: 33%; text-align:center;">Student</td>
                <td valign="top" style="font-size:20px;width: 33%; text-align:right;">Signature</td>
            </tr>
        </table>
    </div>

</body>  
</html>
